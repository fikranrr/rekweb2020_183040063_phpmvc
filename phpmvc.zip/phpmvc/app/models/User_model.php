<?php



class User_model {
	private $nama = 'Fikran Rakadifa';

	public function getUser() 
	{
	
		return $this->nama;
	
	}
}